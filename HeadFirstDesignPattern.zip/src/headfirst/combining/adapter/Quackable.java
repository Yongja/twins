package headfirst.combining.adapter;

public interface Quackable {
	public void quack();
}
