package headfirst.observer.weatherstationobservable;

public interface DisplayElement {
	public void display();
}
