package headfirst.observer.weatherstation;

public interface DisplayElement {
	public void display();
}
